var win = Titanium.UI.currentWindow;  

//
// Setup tab groups
//
var tabGroupActivity = Titanium.UI.createTabGroup();// Activity Event window

//
// Setup the windows that the home screen will be able to open
//

var eventInfo = Titanium.UI.createWindow({  
    title:'',  
    url:'main_windows/eventInfo.js'  
});  

var eventInfoTab = Titanium.UI.createTab({  
    title:'Event Info',  
    window:eventInfo
});  

var location = Titanium.UI.createWindow({  
    title:'',  
    url:'main_windows/location.js'  
});  

var locationTab = Titanium.UI.createTab({  
    title:'Location',
    window:location
});  


//
// Buttons on the home screen
// 

var btnEventInfo = Titanium.UI.createButton({  
    title:'',  
    top:10,  
    left:20,
    width:128,  
    height:128,
    backgroundImage: '/main_windows/Home_Icons/event.png',  
    borderRadius:1,  
    font:{fontFamily:'Arial',fontWeight:'bold',fontSize:14}  
});  
win.add(btnEventInfo);

var btnLocation = Titanium.UI.createButton({  
    title:'',  
    top:10,  
    left:150,
    width:128,  
    height:128,
    backgroundImage: '/main_windows/Home_Icons/maps.png',  
    borderRadius:1,  
    font:{fontFamily:'Arial',fontWeight:'bold',fontSize:14}  
});  
win.add(btnLocation);

var btnOwnersPhotos = Titanium.UI.createButton({  
    title:'',  
    top:150,  
    left:20,
    width:128,  
    height:128,
    backgroundImage: '/main_windows/Home_Icons/photos.png',  
    borderRadius:1,  
    font:{fontFamily:'Arial',fontWeight:'bold',fontSize:14}  
});  
win.add(btnOwnersPhotos);

//
// Action Events for the buttons on the home screen
//

btnEventInfo.addEventListener('click',function(e)  
{     
    eventInfo.idKey = win.idKey;
    eventInfo.site_url = win.site_url;
    
    tabGroupActivity.addTab( eventInfoTab );
    tabGroupActivity.open();
    
});

btnLocation.addEventListener('click',function(e)  
{  
    location.idKey = win.idKey;
    location.site_url = win.site_url;
    
    tabGroupActivity.addTab( locationTab );
    tabGroupActivity.open();
    
});
