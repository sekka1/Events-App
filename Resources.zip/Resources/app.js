/////////
// Login
/////////

// Setup Variables
var site_url = 'http://smurf.grep-r.com/';

// this sets the background color of the master UIView (when there are no windows/tab groups on it)  
Titanium.UI.setBackgroundColor('#fff');  

var tabGroup = Titanium.UI.createTabGroup();// Login window
var tabGroup2 = Titanium.UI.createTabGroup(); // Post login windows

//var main    = Titanium.UI.createWindow();  
//var mainTab = Titanium.UI.createTab();  

var login = Titanium.UI.createWindow({  
    title:'User Authentication',
    url:'main_windows/login.js'  
});  

var loginTab = Titanium.UI.createTab({  
    title:"Login",  
    window:login  
});  
var home = Titanium.UI.createWindow({  
    title:'Home Page',
    url:'main_windows/home.js'  
});  

var homeTab = Titanium.UI.createTab({  
    title:"Home Page",  
    window:home  
});  



tabGroup.addTab(loginTab);
tabGroup.open();

// GrantEntrance function which will close out the login window and
// open up the iVMS windows/tabs
Ti.App.addEventListener('grantEntrance', function(event)  
{  
    
    home.site_url = site_url;
    home.idKey = event.idKey;
     
    // Closing the tabGroup that is holding the login tab
    tabGroup.close();
    
    // Open up the tabGroup that has the main windows/tabs
    tabGroup2.addTab(homeTab);
    //tabGroup2.addTab(availabilityTab);
    tabGroup2.open();
     
}); 

